@if($users->count())
    @foreach($users as $user)
        <div class="card">
              <div class="card-body">
                    <h5 class="card-title">
                          <a href="{{route('user',$user->id)}}">{{$user->name}}</a>
                    </h5>
                    <img class="card-img-top img-responsive"
                    src="{{asset('images')}}/person{{$user->id}}.jpg" alt="{{$user->name}}">
                    <small>ผู้ติดตาม
                          <span class="badge badge-primary followers">
                                  {{$user->followers()->get()->count()}}
                          </span>
                    </small>
                    <small>กำลังติดตาม
                          <span class="badge badge-primary followings">
                                {{$user->followings()->get()->count()}}
                          </span>
                    </small>
              </div>
              <button style="margin:10px" type="button"
                class="btn btn-primary btn-follow"
                data-id="{{$user->id}}"
                @if(auth()->user()->id == $user->id)
                    disabled
                @endif
                >
                <strong>
                  @if(auth()->user()->isFollowing($user))
                        เลิกติดตาม
                  @else
                        ติดตาม
                  @endif
                </strong>
              </button>
        </div>
    @endforeach
@else
      <strong style="color:red">ไม่พบข้อมูล!!!</strong>
@endif
