<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $users=User::get();//ดึงข้อมูล user 10 คน
        return view('home',compact("users"));
    }
    public function user($id){
          $user=User::find($id);
          return view('user',compact('user'));
    }
    public function follow(Request $request){
           $user=User::find($request->user_id);// ข้อมูลคนทีเราไปกด follow
           $response=auth()->user()->toggleFollow($user);// กระบวนการ follow / unfollow
           return response()->json(['success'=>$response]);
    }
}
