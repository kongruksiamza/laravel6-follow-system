<?php if($users->count()): ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
              <div class="card-body">
                    <h5 class="card-title">
                          <a href="<?php echo e(route('user',$user->id)); ?>"><?php echo e($user->name); ?></a>
                    </h5>
                    <img class="card-img-top img-responsive"
                    src="<?php echo e(asset('images')); ?>/person<?php echo e($user->id); ?>.jpg" alt="<?php echo e($user->name); ?>">
                    <small>ผู้ติดตาม
                          <span class="badge badge-primary followers">
                                  <?php echo e($user->followers()->get()->count()); ?>

                          </span>
                    </small>
                    <small>กำลังติดตาม
                          <span class="badge badge-primary followings">
                                <?php echo e($user->followings()->get()->count()); ?>

                          </span>
                    </small>
              </div>
              <button style="margin:10px" type="button"
                class="btn btn-primary btn-follow"
                data-id="<?php echo e($user->id); ?>"
                <?php if(auth()->user()->id == $user->id): ?>
                    disabled
                <?php endif; ?>
                >
                <strong>
                  <?php if(auth()->user()->isFollowing($user)): ?>
                        เลิกติดตาม
                  <?php else: ?>
                        ติดตาม
                  <?php endif; ?>
                </strong>
              </button>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
      <strong style="color:red">ไม่พบข้อมูล!!!</strong>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\followsystem\resources\views/users.blade.php ENDPATH**/ ?>